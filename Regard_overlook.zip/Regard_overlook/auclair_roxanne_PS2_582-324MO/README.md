# Regard sur Overlook

[Développement web - Projet vous êtes le héros](https://smnarnold.com/projets/vous-etes-le-heros)


**Genre**: suspense, horreur


**Inspiration**: [The Shining](https://www.imdb.com/title/tt0081505/)


**Palette de couleurs**: [coolors.co](https://coolors.co/452103-690500-fbf2c0-dc7f2e-000000)


## Diagramme 

![diagramme](./assets/schema2.png)