Ce dossier contient les images et fichiers nécessaires au projet.
